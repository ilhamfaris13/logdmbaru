require('./bootstrap');
require('./signature_pad');
require('alpinejs');
